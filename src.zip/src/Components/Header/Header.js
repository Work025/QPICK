import ""

function Header() {
    return (
        <div className="header">
            <div className="header-logo">
                <h1 className="header-h1">QPICK</h1>
                <p><i className="fas fa-mobile"></i>Выбрать модель телефона</p><i className="fas fa-chevron-down"></i>
            </div>
            <div className="header-ul">
                <div className="items"><i class="fa-brands fa-telegram"></i></div>
                <div className="items"><i className="fas fa-heart"></i></div>
                <div className="items"><i className="fas fa-shopping"></i></div>
            </div>
        </div>
    )
}

export default Header;